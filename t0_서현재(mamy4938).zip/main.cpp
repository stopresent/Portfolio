#include <windows.h>

// D3D 사용에 필요한 라이브러리들을 링크합니다.
#pragma comment(lib, "user32")
#pragma comment(lib, "d3d11")
#pragma comment(lib, "d3dcompiler")

// D3D 사용에 필요한 헤더파일들을 포함합니다.
#include <d3d11.h>
#include <d3dcompiler.h>

// ImGui 관련 헤더
#include "ImGui/imgui.h"
#include "ImGui/imgui_internal.h"
#include "ImGui/imgui_impl_dx11.h"
#include "ImGui/imgui_impl_win32.h"

class URenderer;
class UBall;
class UPrimitive;

bool bUseGravity = true;
float gravity = -9.8f;

bool bUseMagnet = false;
bool bFreezeMagnetBall = false;

UBall* MagnetBall = nullptr;
int MagnetIndex = -1;

// 자력 세기
float MagnetStrength = 0.35f;
float MagnetMinDistSq = 0.01f;
float MagnetMaxImpulse = 0.25f;

// 1. Define the triangle vertices
struct FVertexSimple
{
	float x, y, z;		// Position
	float r, g, b, a;	// Color
};

// Structure for a 3D vector
struct FVector
{
	float x, y, z;
	FVector(float _x = 0, float _y = 0, float _z = 0) : x(_x), y(_y), z(_z) {}

	// 덧셈
	FVector operator+(const FVector& rhs) const
	{
		return FVector(x + rhs.x, y + rhs.y, z + rhs.z);
	}

	// 곱셈 (벡터 * 스칼라)
	FVector operator*(float s) const
	{
		return FVector(x * s, y * s, z * s);
	}

	// 덧셈 대입
	FVector& operator+=(const FVector& rhs)
	{
		x += rhs.x;
		y += rhs.y;
		z += rhs.z;
		return *this;
	}

	// 뺄셈
	FVector operator-(const FVector& rhs) const
	{
		return FVector(x - rhs.x, y - rhs.y, z - rhs.z);
	}

	// 뺄셈대입
	FVector& operator-=(const FVector& rhs)
	{
		x -= rhs.x;
		y -= rhs.y;
		z -= rhs.z;
		return *this;
	}

	// 나누기 (벡터 / 스칼라)
	FVector operator/(float s) const
	{
		return FVector(x / s, y / s, z / s);
	}

};

#include "Sphere.h"

// 삼각형을 하드 코딩
FVertexSimple triangle_vertices[] =
{
	{ 0.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f },	// Top vertex (red)
	{ 1.0f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f },	// Bottom-right vertex (green)
	{ -1.0f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f }	// Bottm-left vertex (blue)
};

// 큐브를 하드 코딩
FVertexSimple cube_vertices[] =
{
	// Front face (Z+)
	{ -0.5f, -0.5f,  0.5f,  1.0f, 0.0f, 0.0f, 1.0f }, // Bottom-left (red)
	{ -0.5f,  0.5f,  0.5f,  1.0f, 1.0f, 0.0f, 1.0f }, // Top-left (yellow)
	{  0.5f, -0.5f,  0.5f,  0.0f, 1.0f, 0.0f, 1.0f }, // Bottom-right (green)
	{ -0.5f,  0.5f,  0.5f,  1.0f, 1.0f, 0.0f, 1.0f }, // Top-left (yellow)
	{  0.5f,  0.5f,  0.5f,  0.0f, 0.0f, 1.0f, 1.0f }, // Top-right (blue)
	{  0.5f, -0.5f,  0.5f,  0.0f, 1.0f, 0.0f, 1.0f }, // Bottom-right (green)

	// Back face (Z-)
	{ -0.5f, -0.5f, -0.5f,  0.0f, 1.0f, 1.0f, 1.0f }, // Bottom-left (cyan)
	{  0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 1.0f, 1.0f }, // Bottom-right (magenta)
	{ -0.5f,  0.5f, -0.5f,  0.0f, 0.0f, 1.0f, 1.0f }, // Top-left (blue)
	{ -0.5f,  0.5f, -0.5f,  0.0f, 0.0f, 1.0f, 1.0f }, // Top-left (blue)
	{  0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 1.0f, 1.0f }, // Bottom-right (magenta)
	{  0.5f,  0.5f, -0.5f,  1.0f, 1.0f, 0.0f, 1.0f }, // Top-right (yellow)

	// Left face (X-)
	{ -0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 1.0f, 1.0f }, // Bottom-left (purple)
	{ -0.5f,  0.5f, -0.5f,  0.0f, 0.0f, 1.0f, 1.0f }, // Top-left (blue)
	{ -0.5f, -0.5f,  0.5f,  0.0f, 1.0f, 0.0f, 1.0f }, // Bottom-right (green)
	{ -0.5f,  0.5f, -0.5f,  0.0f, 0.0f, 1.0f, 1.0f }, // Top-left (blue)
	{ -0.5f,  0.5f,  0.5f,  1.0f, 1.0f, 0.0f, 1.0f }, // Top-right (yellow)
	{ -0.5f, -0.5f,  0.5f,  0.0f, 1.0f, 0.0f, 1.0f }, // Bottom-right (green)

	// Right face (X+)
	{  0.5f, -0.5f, -0.5f,  1.0f, 0.5f, 0.0f, 1.0f }, // Bottom-left (orange)
	{  0.5f, -0.5f,  0.5f,  0.5f, 0.5f, 0.5f, 1.0f }, // Bottom-right (gray)
	{  0.5f,  0.5f, -0.5f,  0.5f, 0.0f, 0.5f, 1.0f }, // Top-left (purple)
	{  0.5f,  0.5f, -0.5f,  0.5f, 0.0f, 0.5f, 1.0f }, // Top-left (purple)
	{  0.5f, -0.5f,  0.5f,  0.5f, 0.5f, 0.5f, 1.0f }, // Bottom-right (gray)
	{  0.5f,  0.5f,  0.5f,  0.0f, 0.0f, 0.5f, 1.0f }, // Top-right (dark blue)

	// Top face (Y+)
	{ -0.5f,  0.5f, -0.5f,  0.0f, 1.0f, 0.5f, 1.0f }, // Bottom-left (light green)
	{ -0.5f,  0.5f,  0.5f,  0.0f, 0.5f, 1.0f, 1.0f }, // Top-left (cyan)
	{  0.5f,  0.5f, -0.5f,  0.5f, 1.0f, 1.0f, 1.0f }, // Bottom-right (white)
	{ -0.5f,  0.5f,  0.5f,  0.0f, 0.5f, 1.0f, 1.0f }, // Top-left (cyan)
	{  0.5f,  0.5f,  0.5f,  0.5f, 0.5f, 0.0f, 1.0f }, // Top-right (brown)
	{  0.5f,  0.5f, -0.5f,  0.5f, 1.0f, 1.0f, 1.0f }, // Bottom-right (white)

	// Bottom face (Y-)
	{ -0.5f, -0.5f, -0.5f,  0.5f, 0.5f, 0.0f, 1.0f }, // Bottom-left (brown)
	{ -0.5f, -0.5f,  0.5f,  1.0f, 0.0f, 0.0f, 1.0f }, // Top-left (red)
	{  0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 0.5f, 1.0f }, // Bottom-right (purple)
	{ -0.5f, -0.5f,  0.5f,  1.0f, 0.0f, 0.0f, 1.0f }, // Top-left (red)
	{  0.5f, -0.5f,  0.5f,  0.0f, 1.0f, 0.0f, 1.0f }, // Top-right (green)
	{  0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 0.5f, 1.0f }, // Bottom-right (purple)
};

// 일단 메인에 다 넣어보자.
class URenderer
{
public:
	// Direct3D 11 장치(Device)와 장치 컨텍스트(Device Context) 및 스왑 체인(Swap Chain)을 관리하기 위한 포인터들
	ID3D11Device* Device = nullptr; // GPU와 통신하기 위한 Diect3D 장치
	ID3D11DeviceContext* DeviceContext = nullptr; // GPU 명령 실행을 담당하는 컨텍스트
	IDXGISwapChain* SwapChain = nullptr; // 프레임 버퍼를 교체하는 데 사용되는 스왑 체인

	// 렌더링에 필요한 리소스 및 상태를 관리하기 위한 변수들
	ID3D11Texture2D* FrameBuffer = nullptr; // 화면 출력용 텍스처
	ID3D11RenderTargetView* FrameBufferRTV = nullptr; // 텍스처를 렌더 타겟으로 사용하는 뷰
	ID3D11RasterizerState* RasterizerState = nullptr; // 래스터라이저 상태(컬링, 채우기 모드 등 정의)
	ID3D11Buffer* ConstantBuffer = nullptr; // 쉐이더에 데이터를 전달하기 위한 상수 버퍼

	FLOAT ClearColor[4] = { 0.025f, 0.025f, 0.025f, 1.0f };
	D3D11_VIEWPORT ViewportInfo; // 렌더링 영역을 정의하는 뷰포트 정보

public:

	ID3D11VertexShader* SimpleVertexShader;
	ID3D11PixelShader* SimplePixelShader;
	ID3D11InputLayout* SimpleInputLayout;
	unsigned int Stride;

	void CreateShader()
	{
		// Blob : Binary Large OBject
		// CSO : Compiled Shader Object
		ID3DBlob* vertexshaderCSO;
		ID3DBlob* pixelshaderCSO;

		D3DCompileFromFile(L"ShaderW0.hlsl", nullptr, nullptr, "mainVS", "vs_5_0", 0, 0, &vertexshaderCSO, nullptr);

		Device->CreateVertexShader(vertexshaderCSO->GetBufferPointer(), vertexshaderCSO->GetBufferSize(), nullptr, &SimpleVertexShader);

		D3DCompileFromFile(L"ShaderW0.hlsl", nullptr, nullptr, "mainPS", "ps_5_0", 0, 0, &pixelshaderCSO, nullptr);

		Device->CreatePixelShader(pixelshaderCSO->GetBufferPointer(), pixelshaderCSO->GetBufferSize(), nullptr, &SimplePixelShader);

		D3D11_INPUT_ELEMENT_DESC layout[] =
		{
			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "COLOR", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 12, D3D11_INPUT_PER_VERTEX_DATA, 0}
		};

		Device->CreateInputLayout(layout, ARRAYSIZE(layout), vertexshaderCSO->GetBufferPointer(), vertexshaderCSO->GetBufferSize(), &SimpleInputLayout);

		Stride = sizeof(FVertexSimple);

		vertexshaderCSO->Release();
		pixelshaderCSO->Release();
	}

	void ReleaseShader()
	{
		if (SimpleInputLayout)
		{
			SimpleInputLayout->Release();
			SimpleInputLayout = nullptr;
		}

		if (SimplePixelShader)
		{
			SimplePixelShader->Release();
			SimplePixelShader = nullptr;
		}

		if (SimpleVertexShader)
		{
			SimpleVertexShader->Release();
			SimpleVertexShader = nullptr;
		}
	}

	void Prepare()
	{
		DeviceContext->ClearRenderTargetView(FrameBufferRTV, ClearColor);

		DeviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

		DeviceContext->RSSetViewports(1, &ViewportInfo);
		DeviceContext->RSSetState(RasterizerState);

		DeviceContext->OMSetRenderTargets(1, &FrameBufferRTV, nullptr);
		DeviceContext->OMSetBlendState(nullptr, nullptr, 0xffffffff);
	}

	void PrepareShader()
	{
		DeviceContext->VSSetShader(SimpleVertexShader, nullptr, 0);
		DeviceContext->PSSetShader(SimplePixelShader, nullptr, 0);
		DeviceContext->IASetInputLayout(SimpleInputLayout);

		// 버텍스 쉐이더에 상수 버퍼를 설정합니다.
		if (ConstantBuffer)
		{
			DeviceContext->VSSetConstantBuffers(0, 1, &ConstantBuffer);
		}
	}

	void RenderPrimitive(ID3D11Buffer* pBuffer, UINT numVertices)
	{
		UINT offset = 0;
		DeviceContext->IASetVertexBuffers(0, 1, &pBuffer, &Stride, &offset);

		DeviceContext->Draw(numVertices, 0);
	}

public:
	ID3D11Buffer* CreateVertexBuffer(FVertexSimple* vertices, UINT byteWidth)
	{
		// 2. Create a vertex buffer
		D3D11_BUFFER_DESC vertexbufferdesc = {};
		vertexbufferdesc.ByteWidth = byteWidth;
		vertexbufferdesc.Usage = D3D11_USAGE_IMMUTABLE; // will never be updated
		vertexbufferdesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;

		D3D11_SUBRESOURCE_DATA vertexbufferSRD = { vertices };

		ID3D11Buffer* vertexBuffer;

		Device->CreateBuffer(&vertexbufferdesc, &vertexbufferSRD, &vertexBuffer);

		return vertexBuffer;
	}

	void ReleaseVertexBuffer(ID3D11Buffer* vertexBuffer)
	{
		vertexBuffer->Release();
	}

public:
	// 렌더러 초기화 함수
	void Create(HWND hWindow)
	{
		// Direct3D 장치 및 스왑 체인 생성
		CreateDeviceAndSwapChain(hWindow);

		// 프레임 버퍼 생성
		CreateFrameBuffer();

		// 래스터라이저 상태 생성
		CreateRasterizerState();

		// 깊이 스텐실 버퍼 및 블렌드 상태는 이 코드에서는 다루지 않음
	}

	// Direct3D 장치 및 스왑 체인을 생성하는 함수
	void CreateDeviceAndSwapChain(HWND hWindow)
	{
		// 지원하는 Direct3D 기능 레벨을 정의
		D3D_FEATURE_LEVEL featurelevels[] = { D3D_FEATURE_LEVEL_11_0 };

		// 스왑 체인 설정 구조체 초기화
		DXGI_SWAP_CHAIN_DESC swapchaindesc = {};
		swapchaindesc.BufferDesc.Width = 0; // 창 크기에 맞게 자동으로 설정
		swapchaindesc.BufferDesc.Height = 0; // 창 크기에 맞게 자동으로 설정
		swapchaindesc.BufferDesc.Format = DXGI_FORMAT_B8G8R8A8_UNORM; // 색상 포맷
		swapchaindesc.SampleDesc.Count = 1; // 멀티 샘플링 비활성화
		swapchaindesc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT; // 렌더 타겟으로 사용
		swapchaindesc.BufferCount = 2; // 더블 버퍼링
		swapchaindesc.OutputWindow = hWindow; // 렌더링할 창 핸들
		swapchaindesc.Windowed = TRUE; // 창 모드
		swapchaindesc.SwapEffect = DXGI_SWAP_EFFECT_FLIP_DISCARD; // 스왑 방식

		// Direct3D 장치와 스왑 체인을 생성
		D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr,
			D3D11_CREATE_DEVICE_BGRA_SUPPORT | D3D11_CREATE_DEVICE_DEBUG,
			featurelevels, ARRAYSIZE(featurelevels), D3D11_SDK_VERSION,
			&swapchaindesc, &SwapChain, &Device, nullptr, &DeviceContext);

		// 생성된 스왑 체인의 정보 가져오기
		SwapChain->GetDesc(&swapchaindesc);

		// 뷰포트 정보 설정
		ViewportInfo = { 0.0f, 0.0f, (float)swapchaindesc.BufferDesc.Width, (float)swapchaindesc.BufferDesc.Height, 0.0f, 1.0f };
	}

	// Direct3D 장치 및 스왑 체인을 해제하는 함수
	void ReleaseDeviceAndSwapChain()
	{
		if (DeviceContext)
		{
			DeviceContext->Flush(); // 남아있는 GPU 명령 실행
		}

		if (SwapChain)
		{
			SwapChain->Release();
			SwapChain = nullptr;
		}

		if (Device)
		{
			Device->Release();
			Device = nullptr;
		}

		if (DeviceContext)
		{
			DeviceContext->Release();
			DeviceContext = nullptr;
		}
	}

	// 프레임 버퍼를 생성하는 함수
	void CreateFrameBuffer()
	{
		// 스왑체인으로 부터 백 버퍼 텍스처 가져오기
		SwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&FrameBuffer);

		// 렌더 타겟 뷰 설정
		D3D11_RENDER_TARGET_VIEW_DESC framebufferRTVdesc = {};
		framebufferRTVdesc.Format = DXGI_FORMAT_B8G8R8A8_UNORM_SRGB; // 색상 포맷
		framebufferRTVdesc.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D; // 2D 텍스처

		Device->CreateRenderTargetView(FrameBuffer, &framebufferRTVdesc, &FrameBufferRTV);
	}

	// 프레임 버퍼를 해제하는 함수
	void ReleaseFrameBuffer()
	{
		if (FrameBuffer)
		{
			FrameBuffer->Release();
			FrameBuffer = nullptr;
		}

		if (FrameBufferRTV)
		{
			FrameBufferRTV->Release();
			FrameBufferRTV = nullptr;
		}
	}

	// 래스터라이저 상태를 생성하는 함수
	void CreateRasterizerState()
	{
		D3D11_RASTERIZER_DESC rasterizerdesc = {};
		rasterizerdesc.FillMode = D3D11_FILL_SOLID; // 채우기 모드
		rasterizerdesc.CullMode = D3D11_CULL_BACK; // 백 페이스 컬링

		Device->CreateRasterizerState(&rasterizerdesc, &RasterizerState);
	}

	// 래스터라이저 상태를 해제하는 함수
	void ReleaseRasterizerState()
	{
		if (RasterizerState)
		{
			RasterizerState->Release();
			RasterizerState = nullptr;
		}
	}

	// 랜더러에 사용된 모든 리소스를 해제하는 함수
	void Release()
	{
		RasterizerState->Release();

		// 랜더 타겟을 초기화
		DeviceContext->OMSetRenderTargets(0, nullptr, nullptr);

		ReleaseFrameBuffer();
		ReleaseDeviceAndSwapChain();
	}

	// 스왑 체인의 백 버퍼와 프론트 버퍼를 교체하여 화면에 출력
	void SwapBuffer()
	{
		SwapChain->Present(1, 0); // 1: VSync 활성화
	}

public:
	struct FConstants
	{
		FVector Offset;
		float Scale;
		float Tint[4];
	};

	void CreateConstantBuffer()
	{
		D3D11_BUFFER_DESC constantbufferdesc = {};
		constantbufferdesc.ByteWidth = (sizeof(FConstants) + 0xf) & 0xfffffff0; // ensure constant buffer size is multiple of 16 bytes
		constantbufferdesc.Usage = D3D11_USAGE_DYNAMIC; // will be updated from CPU every frame
		constantbufferdesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
		constantbufferdesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;

		Device->CreateBuffer(&constantbufferdesc, nullptr, &ConstantBuffer);
	}

	void ReleaseConstantBuffer()
	{
		if (ConstantBuffer)
		{
			ConstantBuffer->Release();
			ConstantBuffer = nullptr;
		}
	}

	void UpdateConstant(FVector Offset, float Scale, float r, float g, float b, float a)
	{
		if (ConstantBuffer)
		{
			D3D11_MAPPED_SUBRESOURCE constantbufferMSR;

			DeviceContext->Map(ConstantBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &constantbufferMSR); // update constant buffer every frame
			FConstants* constants = (FConstants*)constantbufferMSR.pData;
			{
				constants->Offset = Offset;
				constants->Scale = Scale;
				constants->Tint[0] = r;
				constants->Tint[1] = g;
				constants->Tint[2] = b;
				constants->Tint[3] = a;
			}
			DeviceContext->Unmap(ConstantBuffer, 0);
		}
	}

};

class UPrimitive
{
public:
	virtual ~UPrimitive() {}

	// 매 프레임 갱신 (이동, 물리, 상태 변화)
	virtual void Tick(float dt) = 0;

	// 렌더링
	virtual void Render(URenderer& renderer) = 0;

	// 다른 Primitive와의 충돌 처리
	virtual bool ResolveCollision(UPrimitive* other) = 0;

	// 외부에서 힘 / 속도 등을 적용
	virtual void ApplyImpulse(const FVector& v) = 0;
};

class UBall : public UPrimitive
{
public:
	FVector Location;
	FVector Velocity;
	float Radius;
	float Mass;
	static int TotalNumBalls;

public:
	// 생성 / 소멸
	UBall()
	{
		TotalNumBalls++;

		Radius = 0.03f + (float)(rand() % 100) * 0.001f; // 0.03 ~ 0.13

		Mass = Radius;

		const float left = -1.0f + Radius;
		const float right = 1.0f - Radius;
		const float bottom = -1.0f + Radius;
		const float top = 1.0f - Radius;

		float randX = (float)(rand() % 1000) / 999.0f;
		float randY = (float)(rand() % 1000) / 999.0f;

		Location.x = left + (right - left) * randX;
		Location.y = bottom + (top - bottom) * randY;

		const float speed = 0.001f;
		Velocity.x = ((float)(rand() % 100 - 50)) * speed;
		Velocity.y = ((float)(rand() % 100 - 50)) * speed;
	}

	virtual ~UBall()
	{
		TotalNumBalls--;
	}

	virtual void Tick(float dt) override
	{
		if (bUseGravity)
		{
			Velocity.y += gravity * dt;
		}

		Location = Location + Velocity * dt;


		// 2) 벽 튕김 (NDC 기준 -1 ~ 1)
		const float left = -1.0f + Radius;
		const float right = 1.0f - Radius;
		const float bottom = -1.0f + Radius;
		const float top = 1.0f - Radius;

		if (Location.x < left)
		{
			Location.x = left;
			Velocity.x *= -1.0f;
		}
		else if (Location.x > right)
		{
			Location.x = right;
			Velocity.x *= -1.0f;
		}
		if (Location.y < bottom)
		{
			Location.y = bottom;
			Velocity.y *= -1.0f;
		}
		else if (Location.y > top)
		{
			Location.y = top;
			Velocity.y *= -1.0f;
		}

	}

	virtual void Render(URenderer& renderer) override
	{

	}

	virtual bool ResolveCollision(UPrimitive* other) override
	{
		UBall* otherBall = (UBall*)other;
		if (otherBall == nullptr) return false;
		if (otherBall == this) return false;

		// 상대 위치 벡터
		FVector posVec = otherBall->Location - Location;

		float radiusSum = Radius + otherBall->Radius;
		float distSqrt = posVec.x * posVec.x + posVec.y * posVec.y;

		// 안 겹치면 끝
		if (distSqrt >= radiusSum * radiusSum)
		{
			return false;
		}

		// 거리/노멀
		float dist = sqrtf(distSqrt);
		FVector normalVec;

		if (dist > 0.00001f)
		{
			normalVec = posVec / dist; // 정규화
		}
		else
		{
			// 완전 같은 위치면 임의 노멀
			normalVec = FVector(1.0f, 0.0f, 0.0f);
			dist = 0.0f;
		}

		// 1) 겹침을 먼저 풀어준다(포지션 보정)

		bool bIsMagnet1 = (bUseMagnet && bFreezeMagnetBall && (this == MagnetBall));
		bool bIsMagnet2 = (bUseMagnet && bFreezeMagnetBall && (otherBall == MagnetBall));
		float overlap = radiusSum - dist;
		if (overlap > 0.0f)
		{

			if (bIsMagnet1 && !bIsMagnet2)
			{
				// 나는 고정, 상대만 밀기
				otherBall->Location += normalVec * overlap;
			}
			else if (!bIsMagnet1 && bIsMagnet2)
			{
				// 상대가 고정, 나만 밀기
				Location -= normalVec * overlap;
			}
			else
			{
				// 둘 다 일반 공이면 기존 질량비 보정
				float totalMass = Mass + otherBall->Mass;
				float moveA = (otherBall->Mass / totalMass) * overlap;
				float moveB = (Mass / totalMass) * overlap;

				Location -= normalVec * moveA;
				otherBall->Location += normalVec * moveB;
			}
		}


		// 2) 탄성 충돌(속도 갱신)
		FVector rv = otherBall->Velocity - Velocity;
		float velAlongNormal = rv.x * normalVec.x + rv.y * normalVec.y;
		if (velAlongNormal > 0.0f)
		{
			return true;
		}

		// 1D 충돌을 노멀 방향으로 적용
		float j = -(2.0f * velAlongNormal) / (1.0f / Mass + 1.0f / otherBall->Mass);
		FVector impulse = normalVec * j;

		if (!bIsMagnet1)
		{
			Velocity -= impulse / Mass;
		}
		else
		{
			Velocity.x = 0.0f;
			Velocity.y = 0.0f;
		}

		if (!bIsMagnet2)
		{
			otherBall->Velocity += impulse / otherBall->Mass;
		}
		else
		{
			otherBall->Velocity.x = 0.0f;
			otherBall->Velocity.y = 0.0f;
		}


		return true;
	}

	virtual void ApplyImpulse(const FVector& v) override
	{
		if (Mass > 0.000001f)
		{
			Velocity += (v / Mass);
		}

	}
};

struct FPrimitivePool
{
	UPrimitive** PrimitiveList = nullptr;
	int Count = 0;
	int Capacity = 0;

	void EnsureCapacity(int want)
	{
		if (Capacity >= want)
		{
			return;
		}

		int newCap = (Capacity == 0) ? 4 : Capacity;
		while (newCap < want) newCap *= 2;

		UPrimitive** newList = new UPrimitive* [newCap];

		for (int i = 0; i < Count; ++i)
		{
			newList[i] = PrimitiveList[i];
		}

		delete[] PrimitiveList;
		PrimitiveList = newList;
		Capacity = newCap;
	}

	void AddBall()
	{
		EnsureCapacity(Count + 1);
		PrimitiveList[Count] = new UBall();
		Count++;
	}

	void RemoveRandom()
	{
		if (Count <= 0)
		{
			return;
		}

		int idx = rand() % Count;
		delete PrimitiveList[idx];

		Count--;
		PrimitiveList[idx] = PrimitiveList[Count];
		PrimitiveList[Count] = nullptr;
	}

	void SetCount(int desired)
	{
		if (desired < 1) desired = 1;

		while (Count < desired)
		{
			AddBall();
		}

		while (Count > desired)
		{
			RemoveRandom();
		}
	}

	void DestroyAll()
	{
		for (int i = 0; i < Count; ++i)
		{
			delete PrimitiveList[i];
		}

		delete[] PrimitiveList;
		PrimitiveList = nullptr;
		Count = 0;
		Capacity = 0;
	}

};

bool IsBallInPool(FPrimitivePool& Pool, UBall* target)
{
	if (target == nullptr)
	{
		return false;
	}

	for (int i = 0; i < Pool.Count; ++i)
	{
		if (Pool.PrimitiveList[i] == target)
		{
			return true;
		}
	}

	return false;
}

extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

// 각종 메시지를 처리할 함수
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	if (ImGui_ImplWin32_WndProcHandler(hWnd, message, wParam, lParam))
	{
		return true;
	}

	switch (message)
	{
	case WM_DESTROY:
		// Signal taht the app should quit
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}

	return 0;
}

int UBall::TotalNumBalls = 0;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	// 윈도우 클래스 이름
	WCHAR WindowClass[] = L"JungleWindowClass";

	// 윈도우 타이틀바에 표시될 이름
	WCHAR Title[] = L"Game Tech Lab";

	// 각종 메시지를 처리할 함수인 WndPProc의 함수 포인터를 WindowClass 구조체에 넣는다.
	WNDCLASSW wndclass = { 0, WndProc, 0, 0, 0, 0, 0, 0, 0, WindowClass };

	// 윈도우 클래스 등록
	RegisterClassW(&wndclass);

	// 512 x 512 크기에 윈도우 생성
	HWND hWnd = CreateWindowExW(0, WindowClass, Title, WS_POPUP | WS_VISIBLE | WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT, 512, 512,
		nullptr, nullptr, hInstance, nullptr);

	// Renderer Class를 생성합니다.
	URenderer renderer;

	// D3D11 생성하는 함수를 호출합니다.
	renderer.Create(hWnd);

	// 렌더러 생성 직후에 쉐이더를 생성하는 함수를 호출합니다.
	renderer.CreateShader();

	renderer.CreateConstantBuffer();

	// ImGui생성
	IMGUI_CHECKVERSION();
	ImGui::CreateContext();
	ImGuiIO& io = ImGui::GetIO();
	ImGui_ImplWin32_Init((void*)hWnd);
	ImGui_ImplDX11_Init(renderer.Device, renderer.DeviceContext);

	UINT numVerticesSphere = sizeof(sphere_vertices) / sizeof(FVertexSimple);

	ID3D11Buffer* vertexBufferSphere = renderer.CreateVertexBuffer(sphere_vertices, sizeof(sphere_vertices));
	bool bIsExit = false;

	// FPS 제한을 위한 설정
	const int targetFPS = 30;
	const double targetFrameTime = 1000.0 / targetFPS; // 한 프레임의 목표 시간 (밀리초 단위)

	// 고성능 타이머 초기화
	LARGE_INTEGER frequency;
	QueryPerformanceFrequency(&frequency);

	LARGE_INTEGER startTime, endTime;
	LARGE_INTEGER prevTime, curTime;
	double elapsedTime = 0.0f;

	FPrimitivePool Pool;

	Pool.SetCount(1);
	QueryPerformanceCounter(&prevTime);


	// Main Loop (Quit Message가 들어오기 전까지 아래 Loop를 무한히 실행하게 됨)
	while (bIsExit == false)
	{
		MSG msg;

		// 루프 시작 시간 기록
		QueryPerformanceCounter(&startTime);

		QueryPerformanceCounter(&curTime);


		// dt(초)
		float dt = (float)((double)(curTime.QuadPart - prevTime.QuadPart) / (double)frequency.QuadPart);
		prevTime = curTime;

		// 처리할 메시지가 더 이상 없을때 까지 수행
		while (PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE))
		{
			// 키 입력 메시지를 번역
			TranslateMessage(&msg);

			// 메시지를 적절한 윈도우 프로시저에 전달, 메시지가 위에서 등록한 WndProc으로 전달됨
			DispatchMessage(&msg);

			if (msg.message == WM_QUIT)
			{
				bIsExit = true;
				break;
			}
			
		}

		//////////////////////////////////////////
		// 매번 실행되는 코드를 여기에 추가합니다.

		// 준비 작업
		renderer.Prepare();
		renderer.PrepareShader();

		// 1) Tick 단계
		for (int i = 0; i < Pool.Count; ++i)
		{
			UBall* ball = (UBall*)Pool.PrimitiveList[i];

			if (bUseMagnet && bFreezeMagnetBall && (ball == MagnetBall))
			{
				// 좌표 고정 + 속도 0 유지
				ball->Location.x = 0;
				ball->Location.y = 0;
				ball->Velocity.x = 0.0f;
				ball->Velocity.y = 0.0f;
				continue;
			}

			ball->Tick(dt);
		}

		if (bUseMagnet)
		{
			// 자석 공이 삭제됐으면 자동 해제
			if (IsBallInPool(Pool, MagnetBall) == false)
			{
				MagnetBall = nullptr;
				MagnetIndex = -1;
			}

			if (MagnetBall != nullptr)
			{
				FVector magnetPos = MagnetBall->Location;

				for (int i = 0; i < Pool.Count; ++i)
				{
					UBall* ball = (UBall*)Pool.PrimitiveList[i];
					if (ball == MagnetBall) continue;

					FVector dir = magnetPos - ball->Location;

					float distSq = dir.x * dir.x + dir.y * dir.y;

					// 너무 가까우면 폭주하니 최소 거리 보정
					if (distSq < MagnetMinDistSq)
					{
						distSq = MagnetMinDistSq;
					}

					float dist = sqrtf(distSq);

					// 정규화
					FVector n = dir / dist;

					// 간단한 역제곱 힘 (거리 멀면 약하고 가까우면 강함)
					float impulseMag = MagnetStrength / distSq;

					// 프레임당 임펄스 상한 (폭주 방지)
					if (impulseMag > MagnetMaxImpulse)
					{
						impulseMag = MagnetMaxImpulse;
					}

					// dt 반영: "힘"처럼 쓰고 싶으면 dt 곱해주는 게 자연스러움
					FVector impulse = n * (impulseMag * dt);

					ball->ApplyImpulse(impulse);
				}
			}
		}

		// 2) Collision 단계
		for (int i = 0; i < Pool.Count; ++i)
		{
			UBall* ball = (UBall*)Pool.PrimitiveList[i];
			for (int j = i + 1; j < Pool.Count; ++j)
			{
				UBall* otherBall = (UBall*)Pool.PrimitiveList[j];
				ball->ResolveCollision(otherBall);
			}
		}

		// 3) Render 단계
		for (int i = 0; i < Pool.Count; ++i)
		{
			UBall* ball = (UBall*)Pool.PrimitiveList[i];

			// 기본은 흰색(원래 버텍스 컬러 유지)
			float tr = 1.0f, tg = 1.0f, tb = 1.0f, ta = 1.0f;

			// 자석 공이면 빨강으로 틴트
			if (bUseMagnet && ball == MagnetBall)
			{
				tr = 1.0f; tg = 0.2f; tb = 0.2f; ta = 1.0f;
			}

			renderer.UpdateConstant(ball->Location, ball->Radius, tr, tg, tb, ta);
			renderer.RenderPrimitive(vertexBufferSphere, numVerticesSphere);
		}


		// ImGui 렌더링 준비, 컨트롤 설정, 렌더링 요청 함수
		ImGui_ImplDX11_NewFrame();
		ImGui_ImplWin32_NewFrame();
		ImGui::NewFrame();

		// 이후 ImGui UI 컨트롤 추가는 ImGui::NewFrame()과 ImGui::Render() 사이에 위치하게 됩니다.
		ImGui::Begin("Jungle Property Window");
		ImGui::Text("Hello Jungle World!");
		ImGui::Checkbox("Gravity", &bUseGravity);
		static int DesiredBalls = 1;

		//ImGui::Text("TotalNumBalls = %d", UBall::TotalNumBalls);
		ImGui::InputInt("Number Of Balls", &DesiredBalls);
		if (DesiredBalls < 1)
		{
			DesiredBalls = 1;
		}

		ImGui::Checkbox("Use Magnet", &bUseMagnet);
		ImGui::Checkbox("Freeze Magnet Ball", &bFreezeMagnetBall);

		if (ImGui::Button("Pick Random Magnet Ball"))
		{
			if (Pool.Count > 0)
			{
				MagnetIndex = rand() % Pool.Count;
				MagnetBall = (UBall*)Pool.PrimitiveList[MagnetIndex];

				// 고정시 속도도 0으로
				if (MagnetBall && bFreezeMagnetBall)
				{
					MagnetBall->Location.x = 0;
					MagnetBall->Location.y = 0;
					MagnetBall->Velocity.x = 0.0f;
					MagnetBall->Velocity.y = 0.0f;
				}
			}
		}

		ImGui::SliderFloat("MagnetStrength", &MagnetStrength, 0.0f, 3.0f);
		ImGui::SliderFloat("MagnetMaxImpulse", &MagnetMaxImpulse, 0.0f, 2.0f);
		ImGui::Text("MagnetIndex = %d", MagnetIndex);


		ImGui::End();
		Pool.SetCount(DesiredBalls);

		ImGui::Render();
		ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

		// 현재 화면에 보여지는 버퍼와 그리기 작업을 윈한 버퍼를 서로 교환합니다.
		renderer.SwapBuffer();

		do
		{
			Sleep(0);

			// 루프 종료 기간 기록
			QueryPerformanceCounter(&endTime);

			// 한 프레임이 소요된 시간 계산 (밀리초 단위로 변환)
			elapsedTime = (endTime.QuadPart - startTime.QuadPart) * 1000.0 / frequency.QuadPart;
		} while (elapsedTime < targetFrameTime);

		//////////////////////////////////////////
	}

	// 소멸하는 코드를 여기에 추가합니다.

	// ImGui 소멸
	ImGui_ImplDX11_Shutdown();
	ImGui_ImplWin32_Shutdown();
	ImGui::DestroyContext();

	// 버텍스 버퍼 소멸은 Renderer 소멸전에 처리합니다.
	renderer.ReleaseVertexBuffer(vertexBufferSphere);

	Pool.DestroyAll();

	renderer.ReleaseConstantBuffer();

	// 렌더러 소멸 직전에 쉐이더를 소멸 시키는 함수를 호출합니다.
	renderer.ReleaseShader();
	renderer.Release();

	return 0;
}